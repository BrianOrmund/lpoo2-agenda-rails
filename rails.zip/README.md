# Exemplo de aplicação Ruby on Rails

Este é um exemplo da aplicação de agenda de contatos implementado em Ruby on Rails.

Esta é uma aplicação CRUD bem básica, apenas para demonstrar como o CRUD pode ser feito no Ruby on Rails.

Para mais instruções sobre como iniciar uma nova aplicação Rails ou como obter mais informações sobre a framework, visite https://guides.rubyonrails.org/getting_started.html